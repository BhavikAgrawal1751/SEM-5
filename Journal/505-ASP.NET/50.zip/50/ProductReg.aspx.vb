﻿
Partial Class ProductReg
    Inherits System.Web.UI.Page

End Class
